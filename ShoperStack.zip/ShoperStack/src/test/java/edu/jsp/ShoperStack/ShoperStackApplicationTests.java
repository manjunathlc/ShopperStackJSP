package edu.jsp.ShoperStack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoperStackApplicationTests {

	@Test
	void contextLoads() {
	}

}
